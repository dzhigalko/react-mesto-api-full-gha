class UserNotFoundError extends Error {

}

module.exports = UserNotFoundError;
