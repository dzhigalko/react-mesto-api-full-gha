class UnauthorizedError extends Error {

}

module.exports = UnauthorizedError;
