class ForbiddenError extends Error {

}

module.exports = ForbiddenError;
